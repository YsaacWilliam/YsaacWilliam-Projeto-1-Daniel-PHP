<?php
$conexao = mysqli_connect("localhost", "root", "");

if (!$conexao) {
    die("Erro na conexão: " . mysqli_connect_error());
}

$db = mysqli_select_db($conexao, "banco");
