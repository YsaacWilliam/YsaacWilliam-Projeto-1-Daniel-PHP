<?php
include('config.inc.php'); // Conexão com o banco

$resultado = mysqli_query($conexao, "SELECT * FROM jogos ORDER BY data_lancamento DESC");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Jogos Gratuitos</title>
  <style>
    /* Fundo com GIF do Balatro */
    body {
      background: url('imagens/fundo-balatro.gif') no-repeat center center fixed;
      background-size: cover;
      color: white;
      font-family: Arial, sans-serif;
      text-align: center;
      margin: 0;
      padding: 20px;
    }

    h1 {
      margin-bottom: 30px;
    }

    /* Box dos jogos */
    .jogo {
      background: rgba(0,0,0,0.8); /* preto transparente */
      border: 2px solid orange;     /* contorno laranja */
      margin: 20px auto;
      padding: 15px;
      border-radius: 10px;
      width: 60%;
      transition: all 0.3s ease;
    }

    .jogo:hover {
      transform: scale(1.05); /* cresce ao passar o mouse */
    }

    /* Imagem do jogo */
    img { 
      width: 200px; 
      border-radius: 8px; 
      margin-bottom: 10px;
    }

    /* Link de download */
    a { 
      color: #00bfff; 
      text-decoration: none; 
      display: inline-block;
      margin-top: 10px;
      font-weight: bold;
      padding: 5px 10px;
      background: #000; /* fundo preto no botão */
      border-radius: 5px;
      transition: all 0.3s ease;
    }

    a:hover {
      background: orange;
      color: #000;
    }
  </style>
</head>
<body>
  <h1>🎮 Jogos Gratuitos</h1>
  
  <?php while($jogo = mysqli_fetch_assoc($resultado)) { ?>
    <div class="jogo">
      <!-- Imagem do jogo: colocar o link do arquivo ou da imagem aqui -->
      <?php if ($jogo['imagem']) { ?>
        <img src="<?= $jogo['imagem'] ?>" alt="<?= $jogo['nome_jogo'] ?>">
      <?php } ?>

      <!-- Nome e empresa -->
      <h2><?= $jogo['nome_jogo'] ?></h2>
      <p><strong>Empresa:</strong> <?= $jogo['empresa'] ?></p>

      <!-- Descrição -->
      <p><?= $jogo['descricao'] ?></p>

      <!-- Link de download: colocar o link do jogo no campo link_download -->
      <a href="<?= $jogo['link_download'] ?>" download>🔗 Baixar Jogo</a>
    </div>
  <?php } ?>
</body>
</html>
