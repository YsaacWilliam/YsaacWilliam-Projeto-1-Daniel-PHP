<?php

    echo "<h3>Rodapé do site.</h3>";
?>
</body>
</html>