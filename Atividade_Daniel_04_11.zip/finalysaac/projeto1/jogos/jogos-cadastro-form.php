<?php include('config.inc.php'); ?> 
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastrar Jogo</title>
</head>
<body>
  <h1>Cadastrar Novo Jogo</h1>
  <form action="jogos-cadastro.php" method="post" enctype="multipart/form-data">
    <label>Nome do Jogo:</label><br>
    <input type="text" name="nome_jogo" required><br><br>

    <label>Empresa:</label><br>
    <input type="text" name="empresa"><br><br>

    <label>Descrição:</label><br>
    <textarea name="descricao" rows="4" cols="40"></textarea><br><br>

    <label>Link de Download (coloque o link direto do jogo):</label><br>
    <input type="text" name="link_download"><br><br>

    <label>Data de Lançamento:</label><br>
    <input type="date" name="data_lancamento"><br><br>

    <label>Imagem (coloque link direto ou arquivo local):</label><br>
    <input type="file" name="imagem"><br><br>

    <input type="submit" value="Cadastrar">
  </form>
</body>
</html>