<?php
include('config.inc.php');

$id = $_POST['id'];
$nome = $_POST['nome_jogo'];
$empresa = $_POST['empresa'];
$descricao = $_POST['descricao'];
$link = $_POST['link_download'];
$data = $_POST['data_lancamento'];

$sql = "UPDATE jogos SET 
  nome_jogo='$nome',
  empresa='$empresa',
  descricao='$descricao',
  link_download='$link',
  data_lancamento='$data'
  WHERE id=$id";

if (mysqli_query($conexao, $sql)) {
  echo "Alterações salvas com sucesso! <a href='jogos-admin.php'>Voltar</a>";
} else {
  echo "Erro: " . mysqli_error($conexao);
}
?>