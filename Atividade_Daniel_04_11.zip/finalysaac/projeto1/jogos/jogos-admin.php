<?php
require_once ('config.inc.php'); 
 $sql = "SELECT * FROM jogos";
    $resultado = mysqli_query($conexao, $sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Gerenciar Jogos</title>
</head>
<body>
  <h1>Gerenciar Jogos</h1>
  <a href="jogos-cadastro-form.php">Cadastrar Novo Jogo</a> | 
  <a href="../admin/clientes-admin.php">Gerenciar Clientes</a> | 
  <a href="jogos.php">Ver Página Pública</a>
  <hr>
  <table border="1" cellpadding="6">
    <tr>
      <th>ID</th>
      <th>Nome</th>
      <th>Empresa</th>
      <th>Data</th>
      <th>Ações</th>
    </tr>
    <?php while($jogo = mysqli_fetch_assoc($resultado)) { ?>
      <tr>
        <td><?= $jogo['id'] ?></td>
        <td><?= $jogo['nome_jogo'] ?></td>
        <td><?= $jogo['empresa'] ?></td>
        <td><?= $jogo['data_lancamento'] ?></td>
        <td>
          <a href="jogos-altera-form.php?id=<?= $jogo['id'] ?>">Editar</a> |
          <a href="jogos-excluir.php?id=<?= $jogo['id'] ?>" onclick="return confirm('Excluir este jogo?')">Excluir</a>
        </td>
      </tr>
    <?php } ?>
  </table>
</body>
</html>