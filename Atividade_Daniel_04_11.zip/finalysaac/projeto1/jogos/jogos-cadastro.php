<?php
include('config.inc.php'); 

$nome = $_POST['nome_jogo'];
$empresa = $_POST['empresa'];
$descricao = $_POST['descricao'];
$link = $_POST['link_download'];
$data = $_POST['data_lancamento'];

// Upload da imagem (opcional)
$imagem = "";
if (!empty($_FILES['imagem']['name'])) {
  $imagem = 'imagens/' . basename($_FILES['imagem']['name']);
  move_uploaded_file($_FILES['imagem']['tmp_name'], $imagem);
}

$sql = "INSERT INTO jogos (nome_jogo, empresa, descricao, link_download, imagem, data_lancamento)
        VALUES ('$nome', '$empresa', '$descricao', '$link', '$imagem', '$data')";

if (mysqli_query($conexao, $sql)) {
  echo "Jogo cadastrado com sucesso! <a href='jogos-admin.php'>Voltar</a>";
} else {
  echo "Erro: " . mysqli_error($conexao);
}
?>