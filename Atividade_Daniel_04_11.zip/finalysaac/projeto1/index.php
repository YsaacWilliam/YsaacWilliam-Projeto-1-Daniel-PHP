<?php

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Free Games</title>
  <style>
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background: #111; /* fundo escurin */
      color: white;
      line-height: 1.6;
    }

    /* TOPO MENU */
    header {
      background: #222;
      padding: 15px 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    header h1 {
      font-size: 24px;
      color: orange;
    }

    nav ul {
      list-style: none;
      display: flex;
      gap: 30px; 
    }

    nav ul li a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      transition: color 0.3s;
    }

    nav ul li a:hover {
      color: orange;
    }

    /* CONTEÚDO PRINCIPAL */
    main {
      padding: 40px 30px;
      text-align: center;
    }

    main h2 {
      margin-bottom: 20px;
      color: orange;
    }

    main p {
      max-width: 800px;
      margin: 0 auto 30px auto;
      font-size: 18px;
      color: #ddd;
    }

    /* RODAPÉ */
    footer {
      background: #222;
      padding: 20px 30px;
      text-align: center;
      font-size: 14px;
      color: #aaa;
      margin-top: 50px;
    }

    footer a {
      color: orange;
      text-decoration: none;
    }
  </style>
</head>
<body>

  <!-- TOPO E MENU -->
  <header>
    <h1>Free Games</h1>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="quemsomos.php">Quem Somos</a></li>
        <li><a href="admin/index.php">Clientes</a></li>
        <li><a href="jogos/jogos.php">Jogos Gratuitos</a></li> <!-- link para a página de jogos -->
      </ul>
    </nav>
  </header>

  <!-- CONTEÚDO PRINCIPAL -->
  <main>
    <h2>Bem-vindo ao Free Games!</h2>
    <p>
      Este site foi criado para pessoas que amam jogos e querem se divertir sem gastar dinheiro.
      Aqui você encontra links para jogos que estão disponíveis gratuitamente por períodos limitados.
      Nosso objetivo é facilitar o acesso ao entretenimento de qualidade e ajudar você a aproveitar jogos sem comprometer seu orçamento.
    </p>

    <p>
      Navegue pelo menu acima para conhecer mais sobre nosso site, acessar jogos gratuitos e entrar em contato conosco.
    </p>
  </main>

  <!-- RODAPÉ -->
  <footer>
    &copy; 2025 Free Games. Todos os direitos reservados. | Desenvolvido por Ysaac<br>
    Links para jogos gratuitos, dicas e novidades sobre entretenimento online.
  </footer>

</body>
</html>