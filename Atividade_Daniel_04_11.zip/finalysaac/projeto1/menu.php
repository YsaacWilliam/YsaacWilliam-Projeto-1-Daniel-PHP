<?php

    echo "<h3>menu do site.</h3>";
?>
<nav>
    <ul>
        <li><a href="index.php"> Home </a></li>
        <li><a href="?pg=quemsomos"> Quem Somos </a></li>
        <li><a href="?pg=clientes"> Clientes </a></li>
        <li><a href="?pg=faleconosco"> Contato </a></li>
    </ul>
</nav>
