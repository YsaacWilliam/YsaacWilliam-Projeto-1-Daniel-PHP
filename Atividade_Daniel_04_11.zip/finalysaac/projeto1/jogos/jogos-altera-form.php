<?php
include('config.inc.php');
$id = $_GET['id'];
$res = mysqli_query($conexao, "SELECT * FROM jogos WHERE id = $id");
$jogo = mysqli_fetch_assoc($res);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Editar Jogo</title>
</head>
<body>
  <h1>Editar Jogo</h1>
  <form action="jogos-altera.php" method="post">
    <input type="hidden" name="id" value="<?= $jogo['id'] ?>">

    <label>Nome do Jogo:</label><br>
    <input type="text" name="nome_jogo" value="<?= $jogo['nome_jogo'] ?>"><br><br>

    <label>Empresa:</label><br>
    <input type="text" name="empresa" value="<?= $jogo['empresa'] ?>"><br><br>

    <label>Descrição:</label><br>
    <textarea name="descricao"><?= $jogo['descricao'] ?></textarea><br><br>

    <label>Link de Download:</label><br>
    <input type="text" name="link_download" value="<?= $jogo['link_download'] ?>"><br><br>

    <label>Data de Lançamento:</label><br>
    <input type="date" name="data_lancamento" value="<?= $jogo['data_lancamento'] ?>"><br><br>

    <input type="submit" value="Salvar Alterações">
  </form>
</body>
</html>