<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <style>
        h3{
            color: blue;
        }
    </style>
</head>
<body>
<?php

    echo "<h1>Topo do site.</h1>";