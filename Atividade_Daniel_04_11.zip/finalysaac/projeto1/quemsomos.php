<?php
    echo "<h3>Quem somos</h3>";
    echo "<p>Um parágrafo de texto qualquer.</p>";
