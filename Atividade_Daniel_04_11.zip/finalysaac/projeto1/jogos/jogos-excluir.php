<?php
include('config.inc.php'); 
$id = $_GET['id'];
mysqli_query($conexao, "DELETE FROM jogos WHERE id=$id");
header("Location: jogos-admin.php");
?>